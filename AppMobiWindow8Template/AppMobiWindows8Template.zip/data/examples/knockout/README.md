# jqUi demo using knockout.js for the MVVM pattern

This demo shows how to use jqUi and knockout.js, a popular MVVM pattern.

The general app layout uses jqUi, but the content is driven by knockout.js.  We use the swipe commands to bring up an archive button.