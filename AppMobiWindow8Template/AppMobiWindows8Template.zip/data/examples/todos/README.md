# jqMobi todo JS demo

This demo shows how you can use jqMobi and backbone.js to create applications.  We've modified the backbone.js todo example and replaced jQuery calls to jqMobi.

This does not use jqUi, but does use a few jqMobi plugins, like jq.fx.js and jq.css3animate.js